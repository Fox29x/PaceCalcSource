import csv

#use in save_csv() function
paces = [] #creates empty list
month = int(ent4.get())
day = int(ent5.get())
year = int(ent6.get())
date = datetime.date(year, month, day)
pace = ent7.get()
paces.append(date)
paces.append(pace)
#writes to paces.csv file
with open('paces.csv', 'a', newline="") as writeFile:
    writer = csv.writer(writeFile)
    writer.writerow(paces)    