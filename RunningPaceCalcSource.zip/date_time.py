import datetime

# today's date code 
# use in usetoday() function
shortdate = datetime.date.today()
print(shortdate)

# allows for alternate date 
# use in save_csv() function
month=int(0)
day=int(0)
year=int(0)
date = datetime.date(month, day, year)
print(date)