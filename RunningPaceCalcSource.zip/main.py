from tkinter import *
import datetime
import csv

def showpace():
    minutes = int(e1.get())
    seconds = int(e2.get())
    miles = float(e3.get())
    mpm = minutes/miles 
    mpm_s = int(mpm * 60) 
    spm = seconds/miles 
    total_s = mpm_s + spm  
    mpm = total_s/60  
    mpm_int = int(mpm) 
    spm = (mpm-mpm_int)*60  
    spm = int(spm)  
    pace = f"{mpm_int}:{spm:02}"
    e7.delete(0,END)
    e7.insert(0,pace)

def Date():
    shortdate = datetime.date.today()
    shortdate = str(shortdate)
    e4.delete(0,END)
    e4.insert(0,shortdate[5:7])
    e5.delete(0,END)
    e5.insert(0,shortdate[8:])
    e6.delete(0,END)
    e6.insert(0,shortdate[0:4])
def save_csv():
    paces = [] #creates empty list
    month = int(e4.get())
    day = int(e5.get())
    year = int(e6.get())
    date = datetime.date(year, month, day)
    pace = e7.get()
    paces.append(date)
    paces.append(pace)
    #writes to paces.csv file
    with open('paces.csv', 'a', newline="") as writeFile:
        writer = csv.writer(writeFile)
        writer.writerow(paces)


m = Tk()
m.title("Running Pace Calculator")
m.configure(bg="#008080")


t1 = Label(m,bg="#008080",pady=7,padx=7,text="Running Pace Calculator",font=("Cambria", 15, 'bold'))
l1 = Label(m,bg="#008080",pady=6,padx=6,text="Minutes:",font=("Cambria", 12))
l2 = Label(m,bg="#008080",pady=6,padx=6,text="Seconds:",font=("Cambria", 12))
l3 = Label(m,bg="#008080",pady=6,padx=6,text="Miles:",font=("Cambria", 12))
l4 = Label(m,bg="#008080",pady=6,padx=6,text="Date:",font=("Cambria", 12))
l5 = Label(m,bg="#008080",pady=6,padx=6,text="Or Enter Past Date:",font=("Cambria", 11, 'bold'))
l6 = Label(m,bg="#008080",pady=6,padx=6,text="Month:",font=("Cambria", 12))
l7 = Label(m,bg="#008080",pady=6,padx=6,text="Day:",font=("Cambria", 12))
l8 = Label(m,bg="#008080",pady=6,padx=6,text="Year:",font=("Cambria", 12))
l9 = Label(m,bg="#008080")
l10 = Label(m,bg="#008080",pady=6,padx=6,text="Pace/Mile:",font=("Cambria", 12))

b1 = Button(m,text = "Use Today",fg = "blue",padx=6,pady=6,font=("Cambria", 10,'underline'), command=Date)
b2 = Button(m,text = "Show Pace", fg = "blue",padx=6,pady=6,font=("Cambria", 9,'underline'), command=showpace)
b3 = Button(m,text = "Save",fg = "blue",padx=6,pady=6,font=("Cambria", 10, 'underline'), command=save_csv)

e1 = Entry(m,width=10)
e2 = Entry(m,width=10)
e3 = Entry(m,width=10)
e4 = Entry(m,width=5)
e5 = Entry(m,width=5)
e6 = Entry(m,width=5)
e7 = Entry(m,width=15)


t1.grid(row=0,columnspan=2)
l1.grid(row=1,column=0,sticky=W)
l2.grid(row=2,column=0,sticky=W)
l3.grid(row=3,column=0,sticky=W)
l4.grid(row=4,column=0,sticky=W)
l5.grid(row=6,column=0,sticky=W)
l6.grid(row=6,column=1)
l7.grid(row=6,column=2,sticky=W)
l8.grid(row=6,column=3,sticky=W)
l9.grid(row=8,column=1)
e1.grid(row=1,column=1)
e2.grid(row=2,column=1)
e3.grid(row=3,column=1)
e4.grid(row=7,column=1)
e5.grid(row=7,column=2)
e6.grid(row=7,column=3)
e7.grid(row=9,column=1,sticky=W)
b1.grid(row=4,column=1)
b2.grid(row=7,column=0,sticky=E+W)
b3.grid(row=10,column=1,sticky=E+W)
l10.grid(row=9,column=0,sticky=W)


m.mainloop()