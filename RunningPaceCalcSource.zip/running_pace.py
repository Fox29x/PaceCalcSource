#--will be part of showpace() function
minutes = int(0) #from ent1
seconds = int(0) #from ent2
miles = float(0) #from ent3
#------------
#calcs based on 24:59 in 3.1 miles
mpm = minutes/miles #7.74 mins
mpm_s = int(mpm * 60) #464.4 secs
spm = seconds/miles #19.03
total_s = mpm_s + spm  #483.43
mpm = total_s/60  #8.05
mpm_int = int(mpm) #8
spm = (mpm-mpm_int)*60  #.05*60=3.0
spm = int(spm)  #3
pace = f"{mpm_int}:{spm:02}"
#-----display pace code below